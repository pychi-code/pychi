# pychi

A Python package for simulating the propagation of optical pulses in nonlinear materials.
